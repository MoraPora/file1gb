/**
 * Sets all the check boxes on the form to the same value as the checbox identified by the checkboxid
 *
 * @param checkBoxId {String} The id of the select all checkbox
 * @param formId {String} The id of the form to clear or check all the check boxes on
 */
function checkboxChanged(checkBoxId, formId) {
    var cbox = document.getElementById(checkBoxId);
    var checkedValue = cbox.checked;
    var form = document.getElementById(formId);
    for (var i=0;i<form.elements.length;i++) {
        var elt = form.elements[i];
        if ( elt.type=='checkbox') {
            elt.checked = checkedValue;
        }
    }
}

/**
 * Gets the number of items checked on the form identified by the formId parameter
 *
 * @param formId The corm to count checked checkboxes on
 * @return {Number} The number of checked items on the form
 */
function getNumberChecked(formId){
    var numChecked = 0;
    var form = document.getElementById(formId);
    for (var i=0;i<form.elements.length;i++) {
        var elt = form.elements[i];
        if ( elt.type=='checkbox') {
            if(elt.checked == true){
                numChecked ++;
            }
        }
    }
    return numChecked;
}

/**
 * Checks for one and only checkbox checked on the form and returns true if only one checked.  If
 * checked != 1, pop up an alert with the message that was passed in and return false
 * Used in the admin and sponsor user views
 * @param formId {String} The form we are trying to call the function on
 * @param message {String} The message to show if the number of checked checkboxes != 1
 * @return {Boolean} true if edit is allowed, false if not
 */
function verifySingleSelection(formId, message){
    var numChecked = getNumberChecked(formId);
    if (numChecked == 1){
        return true;
    }
    alert(message);
    return false;
}

/**
 * Checks for 1 or more checkboxes checked on the form and returns true if one or more checked.  If
 * not,  pop up an alert with the message that was passed in and return false
 * Used in the admin and sponsor device views
 * @param formId {String} The form we are trying to call the function on
 * @param message {String} The message to show if the number of checked checkboxes is less than 1
 * @return {Boolean} true if edit is allowed, false if not
 */
function verifyMultiSelection(formId, message){
    var numChecked = getNumberChecked(formId);
    if (numChecked > 0){
        return true;
    }
    alert(message);
    return false;
}

/**
 * Checks for one and only checkbox checked on the form and returns true if only one checked.  If
 * not,  pop up an alert with the message that was passed in and return false
 * Used in the admin and sponsor device and user views
 * @param formId {String} The form we are trying to call the function on
 * @param confirmMessage {String} The are you sure you want to do this? message
 * @param selectMessage {String} The message to show if the number of checked checkboxes != 1
 * @return {Boolean} true if delete is allowed, false if not
 */
function confirmSingleSelection(formId, confirmMessage, selectMessage){
    var numChecked = getNumberChecked(formId);
    if (numChecked == 1){
        if(confirm(confirmMessage)){
            return true;
        }else{
            return false;
        }
    }else{
        alert(selectMessage);
        return false;
    }
}


/**
 * Checks for 1 or more checkboxes checked on the form and returns true if one or more checked.  If
 * not,  pop up an alert with the message that was passed in and return false
 * Used in the admin and sponsor device and user views
 * @param formId {String} The form we are trying to call the function on
 * @param confirmMessage {String} The are you sure you want to do this? message
 * @param selectMessage {String} The message to show if the number of checked checkboxes is less than 1
 * @return {Boolean} true if delete is allowed, false if not
 */
function confirmMultiSelection(formId, confirmMessage, selectMessage){
    var numChecked = getNumberChecked(formId);
    if (numChecked > 0){
        if(confirm(confirmMessage)){
            return true;
        }else{
            return false;
        }
    }else{
        alert(selectMessage);
        return false;
    }
}

/**
 * Notifies the user via a popup that the task cannot be currently performed and the reason why.
 * @param formId {String} The form we are trying to call the function on
 * @param canNotBePerformedMessage {String} The message to show if the number of checked checkboxes is less than 1
 * @return {Boolean} false
 */
function notifyOnCannotBePerformed(formId, canNotBePerformedMessage){
    alert(canNotBePerformedMessage);
    return false;
}

/**
 * Appends a hidden field to the form identified by the formId and submits the form
 *
 * @param formId {String} The form to add the hidden input field to
 * @param field {String} The name of the field to insert
 * @param value {String} The value of the field to insert
 */
function linkPost(formId, field, value){
    if(!value){
        var value = field;
    }
    var form = document.getElementById(formId);
    var hiddenField = document.createElement("input");
    hiddenField.setAttribute("type", "hidden");
    hiddenField.setAttribute("name", field);
    hiddenField.setAttribute("value", value);
    form.appendChild(hiddenField);
    form.submit();
}

/**
 * Appends a hidden field to the form identified by the formId and submits the form
 *
 * @param formId {String} The form to add the hidden input field to
 * @param field1 {String} The name of the first field to insert
 * @param value1 {String} The value of the first field to insert
 * @param field2 {String} The name of the second field to insert
 * @param value2 {String} The value of the second field to insert
 */
function linkPost(formId, field1, value1, field2, value2){
    var form = document.getElementById(formId);
    if(!value1){
        var value1 = field1;
    }
    var hiddenField1 = document.createElement("input");
    hiddenField1.setAttribute("type", "hidden");
    hiddenField1.setAttribute("name", field1);
    hiddenField1.setAttribute("value", value1);
    form.appendChild(hiddenField1);

    if(!value2){
        var value2 = field2;
    }
    var hiddenField2 = document.createElement("input");
    hiddenField2.setAttribute("type", "hidden");
    hiddenField2.setAttribute("name", field2);
    hiddenField2.setAttribute("value", value2);
    form.appendChild(hiddenField2);
    form.submit();
}

/**
 * Appends a hidden field to the form identified by the formId and submits the form
 *
 * @param selectId {String} The select to find the selected index and reset the URL
 *                 of the window to the value of the selected option.
 */
function onChangeSelectUrl(selectId) {
    var select = document.getElementById(selectId);
    if (select != null) {
        var selectedIndex = select.selectedIndex;
        var option = select.options[selectedIndex];
        window.location = option.value;
    }
}

/**
 * Redirects the users browser to the passed in url
 *
 * @param url {String} The location to redirect to
 */
function goToUrl(url){
    window.location = url ;
}
