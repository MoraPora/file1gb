
BrowserUtils = {
    version : '4.2.1.DEV'
};

/**
 * Copies all the properties of config to obj.
 * @param {Object} obj The receiver of the properties
 * @param {Object} config The source of the properties
 * @param {Object} defaults A different object that will also be applied for default values
 * @return {Object} returns obj
 * @member BrowserUtils apply
 */
BrowserUtils.apply = function(o, c, defaults){
    // no "this" reference for friendly out of scope calls
    if(defaults){
        Ext.apply(o, defaults);
    }
    if(o && c && typeof c == 'object'){
        for(var p in c){
            o[p] = c[p];
        }
    }
    return o;
};

(function() {
    ua = navigator.userAgent.toLowerCase(),
    check = function(r){
        return r.test(ua);
    },
    DOC = document,
    isStrict = DOC.compatMode == "CSS1Compat",
    isWebKit = check(/webkit/),
    isIPhone = check(/iphone/),
    isIPod = check(/ipod/),
    isIPad = check(/ipad/),
    isIos = isIPhone || isIPod || isIPad,
    isVersion3OrEarlier = check(/3_0/) || check(/3_1/),
    isVersion4OrEarlier = isVersion3OrEarlier || check(/4_0/) || check(/4_1/) || check(/4_2/) || check(/4_3/),
    isVersion5OrEarlier = isVersion4OrEarlier || check(/5_0/) || check(/5_1/),
    isVersion6OrEarlier = isVersion5OrEarlier || check(/6_0/) || check(/6_1/),
    isVersion7 = check(/7_0/) || check(/7_1/),
    isVersion7OrEarlier = isVersion6OrEarlier || isVersion7,
    isIpod_4_2_1 = isIPod && check(/4_2_1/),
    isIos4OrEarlier = isIos && isVersion4OrEarlier,
    isIos_7_0 = isIos && isVersion7,
    isIosLogin = isIos && check(/applewebkit/) && !check(/safari/),
    isKindle = check(/silk-accelerated=true/) || check(/silk-accelerated=false/),
    isNook = check(/nook/),
    isAndroid = check(/android/) || isKindle || isNook,
    isAndroid_4_2_2 = check(/android/) && check(/4\.2\.2/),
    isAndroidPhone = check(/android/) && check(/mobile/),
    isBlackberry = check(/blackberry/) || check(/bb10/),
    isWinPhone8Plus = check(/windows phone 8/) || check(/Windows Phone 10/),
    
    isTablet = isIPad || isNook || isKindle || (isAndroid && !isAndroidPhone),
    
    isOpera = check(/opera/),
    isChrome = check(/chrome/),
    isSafari = !isChrome && check(/safari/),
    isSafari2 = isSafari && check(/applewebkit\/4/), // unique to Safari 2
    isSafari3 = isSafari && check(/version\/3/),
    isSafari4 = isSafari && check(/version\/4/),
    
    isIE = !isOpera && check(/msie/),
    isIE7 = isIE && check(/msie 7/)
    isIE8 = isIE && check(/msie 8/),
    isIE6 = isIE && !isIE7 && !isIE8,
    isBorderBox = isIE && !isStrict,
    
    isGecko = !isWebKit && check(/gecko/),
    isGecko2 = isGecko && check(/rv:1\.8/),
    isGecko3 = isGecko && check(/rv:1\.9/),
    
    isWindows = check(/windows|win32/),
    isMac = check(/macintosh|mac os x/),
    isAir = check(/adobeair/),
    isLinux = check(/linux/),
    isSecure = /^https/i.test(window.location.protocol);

    BrowserUtils.apply(BrowserUtils, {
        /**
         * True if the browser is in strict (standards-compliant) mode, as opposed to quirks mode
         * @type Boolean
         */
        isStrict : isStrict,
        isIPhone : isIPhone,
        isIPod : isIPod,
        isIPad : isIPad,
        isIos : isIos,
        isAndroid : isAndroid,
        isBlackberry : isBlackberry,
        isWinPhone8Plus : isWinPhone8Plus,
        isTablet : isTablet,
        /**
         * True if the detected browser is Opera.
         * @type Boolean
         */
        isOpera : isOpera,
        /**
         * True if the detected browser uses WebKit.
         * @type Boolean
         */
        isWebKit : isWebKit,
        /**
         * True if the detected browser is Chrome.
         * @type Boolean
         */
        isChrome : isChrome,
        /**
         * True if the detected browser is Safari.
         * @type Boolean
         */
        isSafari : isSafari,
        /**
         * True if the detected browser is Safari 3.x.
         * @type Boolean
         */
        isSafari3 : isSafari3,
        /**
         * True if the detected browser is Safari 4.x.
         * @type Boolean^M
         */
        isSafari4 : isSafari4,
        /**
         * True if the detected browser is Safari 2.x.
         * @type Boolean
         */
        isSafari2 : isSafari2,
        /**
         * True if the detected device is an iPod running iOS 4.2.1.
         * @type Boolean
         */
        isIpod_4_2_1 : isIpod_4_2_1,
        /**
         * True if the detected device is an iPod/iPhone/iPad running iOS 4.x or earlier.
         * @type Boolean
         */
        isIos4OrEarlier : isIos4OrEarlier,
        /**
         * True if the detected device is an iPod/iPhone/iPad running iOS 7.0.
         * @type Boolean
         */
        isIos_7_0 : isIos_7_0,
        /**
         * True if the detected device is an iPod/iPhone/iPad running iOS with web kit that is not the safari browser.
         * @type Boolean
         */
        isIosLogin : isIosLogin,
        /**
         * True if the detected device is an Android running version 4.2.2.
         * @type Boolean
         */
        isAndroid_4_2_2 : isAndroid_4_2_2,
        /**
         * True if the detected browser is Internet Explorer.
         * @type Boolean
         */
        isIE : isIE,
        /**
         * True if the detected browser is Internet Explorer 6.x.
         * @type Boolean
         */
        isIE6 : isIE6,
        /**
         * True if the detected browser is Internet Explorer 7.x.
         * @type Boolean
         */
        isIE7 : isIE7,
        /**
         * True if the detected browser is Internet Explorer 8.x.
         * @type Boolean
         */
        isIE8 : isIE8,
        /**
         * True if the detected browser uses the Gecko layout engine (e.g. Mozilla, Firefox).
         * @type Boolean
         */
        isGecko : isGecko,
        /**
         * True if the detected browser uses a pre-Gecko 1.9 layout engine (e.g. Firefox 2.x).
         * @type Boolean
         */
        isGecko2 : isGecko2,
        /**
         * True if the detected browser uses a Gecko 1.9+ layout engine (e.g. Firefox 3.x).
         * @type Boolean
         */
        isGecko3 : isGecko3,
        /**
         * True if the detected browser is Internet Explorer running in non-strict mode.
         * @type Boolean
         */
        isBorderBox : isBorderBox,
        /**
         * True if the detected platform is Linux.
         * @type Boolean
         */
        isLinux : isLinux,
        /**
         * True if the detected platform is Windows.
         * @type Boolean
         */
        isWindows : isWindows,
        /**
         * True if the detected platform is Mac OS.
         * @type Boolean
         */
        isMac : isMac,
        /**
         * True if the detected platform is Adobe Air.
         * @type Boolean
         */
        isAir : isAir,
        /**
         * True if the page is running over SSL
         * @type Boolean
         */
        isSecure : isSecure
    });

})();

